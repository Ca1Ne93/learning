extern void sig_proccess(int signo);
extern void sig_pipe(int signo);
extern void proccess_coon_server(int a);
extern void proccess_coon_client(int a);
