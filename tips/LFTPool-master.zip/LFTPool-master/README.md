# What is LFTPool?
LFTPool is abbreviation of Lock-Free Thread Pool. 
It is built without any lock and it can be compiled and used on ubuntu 3.11.3. It is as simple as:

$ make

Then you will get an executable file named testtpool.

For more informations, see http://blog.csdn.net/xhjcehust/article/details/45844901.
# contact
For any question, just contact me at any time.

mailto: hjxiaohust@gmail.com

Any suggestion is welcome!
